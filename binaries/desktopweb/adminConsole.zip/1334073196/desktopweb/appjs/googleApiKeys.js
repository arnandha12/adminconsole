define(function() {
    var getMapInitiationKey = function() {
        return "AIzaSyCxovVAM9HcQueEGC60fpV9L2RCrFnSg0E";
    };
    return {
        getMapInitiationKey: getMapInitiationKey,
    };
});