define("CustomerAgentPortalModule/frmCSAPortal", function() {
    return function(controller) {
        function addWidgetsfrmCSAPortal() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxLeftPanel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLeftPanel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "305dp",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftPanel.setDefaultUnit(kony.flex.DP);
            var leftMenuNew = new com.adminConsole.navigation.leftMenuNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "leftMenuNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxBg003E75Op100",
                "top": "0dp",
                "width": "100%",
                "appName": "adminConsole",
                "overrides": {
                    "brandLogo": {
                        "src": "infinity_dbx_c360_logo_white_2x.png"
                    },
                    "flxBottomTitle": {
                        "isVisible": false
                    },
                    "flxBrandLogo": {
                        "isVisible": false
                    },
                    "imgBottomLogo": {
                        "src": "logo_white_2x.png"
                    },
                    "leftMenuNew": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "100%",
                        "isVisible": true,
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeftPanel.add(leftMenuNew);
            var flxRightPanel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRightPanel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "305dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox0b7aaa2e3bfa340",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightPanel.setDefaultUnit(kony.flex.DP);
            var flxHeaderDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxHeaderDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "35dp",
                "skin": "slFbox",
                "top": "20dp",
                "width": "400dp",
                "zIndex": 500,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderDropdown.setDefaultUnit(kony.flex.DP);
            var dropdownMainHeader = new com.adminConsole.common.dropdownMainHeader({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "dropdownMainHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "adminConsole",
                "overrides": {
                    "flxDropdown": {
                        "isVisible": false
                    },
                    "imgUpArrow": {
                        "src": "uparrow_2x.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderDropdown.add(dropdownMainHeader);
            var flxMainHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "106dp",
                "id": "flxMainHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainHeader.setDefaultUnit(kony.flex.DP);
            var mainHeader = new com.adminConsole.header.mainHeader({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "106px",
                "id": "mainHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox1",
                "top": 0,
                "width": "100%",
                "appName": "adminConsole",
                "overrides": {
                    "btnAddNewOption": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.frmCompanies.CreateCompany\")",
                        "isVisible": false,
                        "right": "0dp"
                    },
                    "btnDropdownList": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mainHeader.DOWNLOADLIST\")",
                        "isVisible": false
                    },
                    "flxButtons": {
                        "right": "35dp",
                        "width": "400dp"
                    },
                    "flxHeaderSeperator": {
                        "isVisible": false
                    },
                    "imgLogout": {
                        "src": "img_logout.png"
                    },
                    "lblHeading": {
                        "text": "Customer Agent Portal"
                    },
                    "mainHeader": {
                        "height": "106px"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMainHeader.add(mainHeader);
            var flxScrollContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "85%",
                "id": "flxScrollContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "106dp",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollContainer.setDefaultUnit(kony.flex.DP);
            var flxSegContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "10dp",
                "clipBounds": true,
                "id": "flxSegContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "right": "35dp",
                "skin": "sknflxffffffoptemplateop3px",
                "top": "0dp",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegContainer.setDefaultUnit(kony.flex.DP);
            var flxLoanHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "65px",
                "id": "flxLoanHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknflxffffffop100",
                "top": "0",
                "zIndex": 11,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanHeader.setDefaultUnit(kony.flex.DP);
            var flxUsersHeaderFullName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxUsersHeaderFullName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "10%",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsersHeaderFullName.setDefaultUnit(kony.flex.DP);
            var lblUsersHeaderName = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblUsersHeaderName",
                "isVisible": true,
                "skin": "sknlblLato696c7312px",
                "text": "Sr No",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblLatoBold00000012px"
            });
            var lblSortName = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSortName",
                "isVisible": false,
                "left": "7dp",
                "skin": "sknIcon15px",
                "text": "",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblCursorFont"
            });
            flxUsersHeaderFullName.add(lblUsersHeaderName, lblSortName);
            var flxDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate.setDefaultUnit(kony.flex.DP);
            var CopylblUsersHeaderName0eca5ca15ae724b = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "CopylblUsersHeaderName0eca5ca15ae724b",
                "isVisible": true,
                "skin": "sknlblLato696c7312px",
                "text": "Date",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblLatoBold00000012px"
            });
            var CopylblSortName0g5b1b20ca4f644 = new kony.ui.Label({
                "centerY": "50%",
                "id": "CopylblSortName0g5b1b20ca4f644",
                "isVisible": false,
                "left": "7dp",
                "skin": "sknIcon15px",
                "text": "",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblCursorFont"
            });
            flxDate.add(CopylblUsersHeaderName0eca5ca15ae724b, CopylblSortName0g5b1b20ca4f644);
            var flxUsersHeaderUsername = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxUsersHeaderUsername",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsersHeaderUsername.setDefaultUnit(kony.flex.DP);
            var lblUsersHeaderUsername = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblUsersHeaderUsername",
                "isVisible": true,
                "left": "0px",
                "skin": "sknlblLato696c7312px",
                "text": "National ID/Iqama",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblLatoBold00000012px"
            });
            var lblSortUsername = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSortUsername",
                "isVisible": false,
                "left": "7dp",
                "skin": "sknIcon15px",
                "text": "",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblCursorFont"
            });
            flxUsersHeaderUsername.add(lblUsersHeaderUsername, lblSortUsername);
            var flxUsersHeaderEmailId = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxUsersHeaderEmailId",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsersHeaderEmailId.setDefaultUnit(kony.flex.DP);
            var lblUsersHeaderEmail = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblUsersHeaderEmail",
                "isVisible": true,
                "left": "0px",
                "skin": "sknlblLato696c7312px",
                "text": "Name",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblLatoBold00000012px"
            });
            var lblSortEmail = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSortEmail",
                "isVisible": false,
                "left": "7dp",
                "skin": "sknIcon15px",
                "text": "",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblCursorFont"
            });
            flxUsersHeaderEmailId.add(lblUsersHeaderEmail, lblSortEmail);
            var flxUsersHeaderRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxUsersHeaderRole",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsersHeaderRole.setDefaultUnit(kony.flex.DP);
            var lblUsersHeaderRole = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblUsersHeaderRole",
                "isVisible": true,
                "left": "0px",
                "skin": "sknlblLato696c7312px",
                "text": "Phone",
                "top": 0,
                "width": "35px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblLatoBold00000012px"
            });
            var lblSortRole = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSortRole",
                "isVisible": false,
                "left": "7dp",
                "skin": "sknIcon15px",
                "text": "",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblCursorFont"
            });
            flxUsersHeaderRole.add(lblUsersHeaderRole, lblSortRole);
            var flxUsersHeaderStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxUsersHeaderStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsersHeaderStatus.setDefaultUnit(kony.flex.DP);
            var lblUsersHeaderStatus = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblUsersHeaderStatus",
                "isVisible": true,
                "left": "0px",
                "skin": "sknlblLato696c7312px",
                "text": "Application ID",
                "top": 0,
                "width": "80px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblLatoBold00000012px"
            });
            var lblFilterStatus = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFilterStatus",
                "isVisible": false,
                "left": "7dp",
                "skin": "sknIcon15px",
                "text": "",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlblCursorFont"
            });
            flxUsersHeaderStatus.add(lblUsersHeaderStatus, lblFilterStatus);
            var lblUsersHeaderSeperator = new kony.ui.Label({
                "bottom": 0,
                "height": "1px",
                "id": "lblUsersHeaderSeperator",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "skin": "sknLblTableHeaderLine",
                "text": ".",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoanHeader.add(flxUsersHeaderFullName, flxDate, flxUsersHeaderUsername, flxUsersHeaderEmailId, flxUsersHeaderRole, flxUsersHeaderStatus, lblUsersHeaderSeperator);
            var flxSegmentUsers = new kony.ui.FlexContainer({
                "bottom": "10dp",
                "clipBounds": false,
                "id": "flxSegmentUsers",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0ib23b966328c4c",
                "top": "65dp",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegmentUsers.setDefaultUnit(kony.flex.DP);
            var segLoanDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "data": [{
                    "lblAppId": "",
                    "lblDOB": "",
                    "lblDateTime": "",
                    "lblFontIconOptions": "",
                    "lblName": "",
                    "lblNationalId": "",
                    "lblSeperator": "",
                    "lblStatus": ""
                }],
                "groupCells": false,
                "id": "segLoanDetails",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "2px",
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "sknseg3pxRadius",
                "rowTemplate": "flxLoanApplications",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": true,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxLoanApplications": "flxLoanApplications",
                    "flxLoanApplicationsContainer": "flxLoanApplicationsContainer",
                    "flxOptions": "flxOptions",
                    "lblAppId": "lblAppId",
                    "lblDOB": "lblDOB",
                    "lblDateTime": "lblDateTime",
                    "lblFontIconOptions": "lblFontIconOptions",
                    "lblName": "lblName",
                    "lblNationalId": "lblNationalId",
                    "lblSeperator": "lblSeperator",
                    "lblStatus": "lblStatus"
                },
                "zIndex": 10,
                "appName": "adminConsole"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegmentUsers.add(segLoanDetails);
            flxSegContainer.add(flxLoanHeader, flxSegmentUsers);
            var flxNoUserData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80%",
                "id": "flxNoUserData",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoUserData.setDefaultUnit(kony.flex.DP);
            var lblNouserData = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblNouserData",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel",
                "text": "No User Data",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoUserData.add(lblNouserData);
            flxScrollContainer.add(flxSegContainer, flxNoUserData);
            flxRightPanel.add(flxHeaderDropdown, flxMainHeader, flxScrollContainer);
            flxMain.add(flxLeftPanel, flxRightPanel);
            var flxCustomerDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerDetails",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBg000000op40",
                "width": "100%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerDetails.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "4%",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "92%",
                "horizontalScrollIndicator": true,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "7.32%",
                "pagingEnabled": false,
                "right": "7.32%",
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopysknBackgroundFFFFFF0f65f34e17dc74f",
                "top": "4%",
                "verticalScrollIndicator": true,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flxTopBar = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "10px",
                "id": "flxTopBar",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknFlxInfoToastBg357C9ENoRadius",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopBar.setDefaultUnit(kony.flex.DP);
            flxTopBar.add();
            var flxClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20px",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20px",
                "skin": "sknFlxffffffCursorPointer",
                "top": "5dp",
                "width": "20px",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxClose.setDefaultUnit(kony.flex.DP);
            var lblClose = new kony.ui.Label({
                "height": "100%",
                "id": "lblClose",
                "isVisible": true,
                "left": "0px",
                "skin": "lblIconGrey",
                "text": "",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(lblClose);
            var flxChannelInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxChannelInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "right": "0px",
                "skin": "CopyslFbox0ge19de9ba87e4d",
                "width": "100%",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannelInfo.setDefaultUnit(kony.flex.DP);
            var flxPreviewMode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "73px",
                "clipBounds": true,
                "height": "35px",
                "id": "flxPreviewMode",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "18px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxPreviewMode.setDefaultUnit(kony.flex.DP);
            var lblPreviewMode = new kony.ui.Label({
                "id": "lblPreviewMode",
                "isVisible": true,
                "left": "0px",
                "skin": "blLatoRegular18px",
                "text": "CUSTOMER DETAILS",
                "top": "12px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPreviewMode.add(lblPreviewMode);
            var flxNameNatid = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "35px",
                "id": "flxNameNatid",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "18px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35px",
                "width": "1000px",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameNatid.setDefaultUnit(kony.flex.DP);
            var flxNameCus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNameCus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "70%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameCus.setDefaultUnit(kony.flex.DP);
            var lblCustomerName = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerName",
                "isVisible": true,
                "left": "0",
                "skin": "sknLbl192b45LatoReg16px",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNameCus.add(lblCustomerName);
            var flxNationalId = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNationalId",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxNationalId.setDefaultUnit(kony.flex.DP);
            var lblNationalId = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNationalId",
                "isVisible": true,
                "left": "0",
                "skin": "sknLbl192b45LatoReg16px",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNationalId.add(lblNationalId);
            flxNameNatid.add(flxNameCus, flxNationalId);
            flxChannelInfo.add(flxPreviewMode, flxNameNatid);
            var flxAdSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0px",
                "clipBounds": true,
                "height": "1px",
                "id": "flxAdSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20px",
                "isModalContainer": false,
                "right": "20px",
                "skin": "sknFlxD7D9E0Separator",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdSeparator.setDefaultUnit(kony.flex.DP);
            flxAdSeparator.add();
            var flxCusDetBasic = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCusDetBasic",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxCusDetBasic.setDefaultUnit(kony.flex.DP);
            var flxBasicdetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBasicdetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxBasicdetails.setDefaultUnit(kony.flex.DP);
            var lblHeaderCus = new kony.ui.Label({
                "id": "lblHeaderCus",
                "isVisible": true,
                "left": "10px",
                "skin": "LblLatoRegular485c7516px",
                "text": "Customer Info",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxAdSeparator0f58b0693acf943 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0px",
                "clipBounds": true,
                "height": "1px",
                "id": "CopyflxAdSeparator0f58b0693acf943",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10px",
                "isModalContainer": false,
                "right": "20px",
                "skin": "sknFlxD7D9E0Separator",
                "top": "10dp",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxAdSeparator0f58b0693acf943.setDefaultUnit(kony.flex.DP);
            CopyflxAdSeparator0f58b0693acf943.add();
            var flxCustomerArname = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCustomerArname",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerArname.setDefaultUnit(kony.flex.DP);
            var CopylblCusPhoneVal0aca51dcb742240 = new kony.ui.Label({
                "id": "CopylblCusPhoneVal0aca51dcb742240",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Customer Arabic Name :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCusArName = new kony.ui.Label({
                "id": "lblCusArName",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerArname.add(CopylblCusPhoneVal0aca51dcb742240, lblCusArName);
            var Label0edfd810bd73348 = new kony.ui.Label({
                "height": "10dp",
                "id": "Label0edfd810bd73348",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPhoneCus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPhoneCus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneCus.setDefaultUnit(kony.flex.DP);
            var lblCusPhoneVal = new kony.ui.Label({
                "id": "lblCusPhoneVal",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Phone :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCusPhoneValue = new kony.ui.Label({
                "id": "lblCusPhoneValue",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhoneCus.add(lblCusPhoneVal, lblCusPhoneValue);
            var CopyLabel0i2c632286b0748 = new kony.ui.Label({
                "height": "10dp",
                "id": "CopyLabel0i2c632286b0748",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCusGender = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCusGender",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxCusGender.setDefaultUnit(kony.flex.DP);
            var lblCusGenderKey = new kony.ui.Label({
                "id": "lblCusGenderKey",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Gender :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCusGenderVal = new kony.ui.Label({
                "id": "lblCusGenderVal",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCusGender.add(lblCusGenderKey, lblCusGenderVal);
            var CopyLabel0eca40de9713c4d = new kony.ui.Label({
                "height": "10dp",
                "id": "CopyLabel0eca40de9713c4d",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCusDOB = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCusDOB",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxCusDOB.setDefaultUnit(kony.flex.DP);
            var lblDobCus = new kony.ui.Label({
                "id": "lblDobCus",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Date of Birth :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDOBVal = new kony.ui.Label({
                "id": "lblDOBVal",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCusDOB.add(lblDobCus, lblDOBVal);
            var CopyLabel0ef32386dea094c = new kony.ui.Label({
                "height": "10dp",
                "id": "CopyLabel0ef32386dea094c",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxIbanNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxIbanNumber",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxIbanNumber.setDefaultUnit(kony.flex.DP);
            var lblIbanNumberKey = new kony.ui.Label({
                "id": "lblIbanNumberKey",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "IBAN :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIbanNumberValue = new kony.ui.Label({
                "id": "lblIbanNumberValue",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIbanNumber.add(lblIbanNumberKey, lblIbanNumberValue);
            var CopyLabel0fd56f4b5dc8b46 = new kony.ui.Label({
                "height": "10dp",
                "id": "CopyLabel0fd56f4b5dc8b46",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddressDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddressDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddressDetails.setDefaultUnit(kony.flex.DP);
            var lblAddrKey = new kony.ui.Label({
                "id": "lblAddrKey",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Address :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAddressValue = new kony.ui.Label({
                "id": "lblAddressValue",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddressDetails.add(lblAddrKey, lblAddressValue);
            var CopyLabel0f8b97705f5bc47 = new kony.ui.Label({
                "height": "10dp",
                "id": "CopyLabel0f8b97705f5bc47",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCIty = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCIty",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxCIty.setDefaultUnit(kony.flex.DP);
            var lblCityKey = new kony.ui.Label({
                "id": "lblCityKey",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "City :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcityVal = new kony.ui.Label({
                "id": "lblcityVal",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCIty.add(lblCityKey, lblcityVal);
            var CopyLabel0da851bf0522b4f = new kony.ui.Label({
                "height": "10dp",
                "id": "CopyLabel0da851bf0522b4f",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxZIpCode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxZIpCode",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxZIpCode.setDefaultUnit(kony.flex.DP);
            var lblZIPCodeKey = new kony.ui.Label({
                "id": "lblZIPCodeKey",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Zip Code :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblZipValue = new kony.ui.Label({
                "id": "lblZipValue",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxZIpCode.add(lblZIPCodeKey, lblZipValue);
            var CopyLabel0i4a66408ffdb4b = new kony.ui.Label({
                "height": "10dp",
                "id": "CopyLabel0i4a66408ffdb4b",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxIBanFile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxIBanFile",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxIBanFile.setDefaultUnit(kony.flex.DP);
            var CopylblIbanNumberKey0b17c5cd8d50948 = new kony.ui.Label({
                "id": "CopylblIbanNumberKey0b17c5cd8d50948",
                "isVisible": true,
                "left": "0",
                "skin": "blLatoRegular18px",
                "text": "IBAN File Download",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIBanFile.add(CopylblIbanNumberKey0b17c5cd8d50948);
            var CopyLabel0g8551faee1464c = new kony.ui.Label({
                "height": "20dp",
                "id": "CopyLabel0g8551faee1464c",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var FlexContainer0a67ba06a40414a = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "FlexContainer0a67ba06a40414a",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "60dp",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0a67ba06a40414a.setDefaultUnit(kony.flex.DP);
            var imgPdfIban = new kony.ui.Image2({
                "height": "100%",
                "id": "imgPdfIban",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "pdf_xxl.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0a67ba06a40414a.add(imgPdfIban);
            flxBasicdetails.add(lblHeaderCus, CopyflxAdSeparator0f58b0693acf943, flxCustomerArname, Label0edfd810bd73348, flxPhoneCus, CopyLabel0i2c632286b0748, flxCusGender, CopyLabel0eca40de9713c4d, flxCusDOB, CopyLabel0ef32386dea094c, flxIbanNumber, CopyLabel0fd56f4b5dc8b46, flxAddressDetails, CopyLabel0f8b97705f5bc47, flxCIty, CopyLabel0da851bf0522b4f, flxZIpCode, CopyLabel0i4a66408ffdb4b, flxIBanFile, CopyLabel0g8551faee1464c, FlexContainer0a67ba06a40414a);
            var flxCusLoanDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCusLoanDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxCusLoanDetails.setDefaultUnit(kony.flex.DP);
            var CopylblHeaderCus0g89398c822d645 = new kony.ui.Label({
                "id": "CopylblHeaderCus0g89398c822d645",
                "isVisible": true,
                "left": "10px",
                "skin": "LblLatoRegular485c7516px",
                "text": "Customer Loan",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxAdSeparator0e180d16f2a1241 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0px",
                "clipBounds": true,
                "height": "1px",
                "id": "CopyflxAdSeparator0e180d16f2a1241",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10px",
                "isModalContainer": false,
                "right": "20px",
                "skin": "sknFlxD7D9E0Separator",
                "top": "10dp",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxAdSeparator0e180d16f2a1241.setDefaultUnit(kony.flex.DP);
            CopyflxAdSeparator0e180d16f2a1241.add();
            var CopyflxPhoneCus0a21bdb93970643 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "CopyflxPhoneCus0a21bdb93970643",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxPhoneCus0a21bdb93970643.setDefaultUnit(kony.flex.DP);
            var CopylblCusPhoneVal0bd7e3429fd804a = new kony.ui.Label({
                "id": "CopylblCusPhoneVal0bd7e3429fd804a",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Loan Offer Amount :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOfferAmount = new kony.ui.Label({
                "id": "lblOfferAmount",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxPhoneCus0a21bdb93970643.add(CopylblCusPhoneVal0bd7e3429fd804a, lblOfferAmount);
            var CopyLabel0ab860f22212745 = new kony.ui.Label({
                "height": "20dp",
                "id": "CopyLabel0ab860f22212745",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxCusGender0eb283b3ea53449 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "CopyflxCusGender0eb283b3ea53449",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCusGender0eb283b3ea53449.setDefaultUnit(kony.flex.DP);
            var CopylblCusGenderKey0dcc6f51c93654d = new kony.ui.Label({
                "id": "CopylblCusGenderKey0dcc6f51c93654d",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Tenor :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTenorvalue = new kony.ui.Label({
                "id": "lblTenorvalue",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxCusGender0eb283b3ea53449.add(CopylblCusGenderKey0dcc6f51c93654d, lblTenorvalue);
            var CopyLabel0ad94a4707e1d41 = new kony.ui.Label({
                "height": "20dp",
                "id": "CopyLabel0ad94a4707e1d41",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxCusDOB0ac36a988bfc84b = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "CopyflxCusDOB0ac36a988bfc84b",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCusDOB0ac36a988bfc84b.setDefaultUnit(kony.flex.DP);
            var CopylblDobCus0hfd18074271b42 = new kony.ui.Label({
                "id": "CopylblDobCus0hfd18074271b42",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Rate :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoanRate = new kony.ui.Label({
                "id": "lblLoanRate",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxCusDOB0ac36a988bfc84b.add(CopylblDobCus0hfd18074271b42, lblLoanRate);
            var CopyLabel0e8b8a19ab28c49 = new kony.ui.Label({
                "height": "20dp",
                "id": "CopyLabel0e8b8a19ab28c49",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxIbanNumber0a10743cbf38143 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "CopyflxIbanNumber0a10743cbf38143",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxIbanNumber0a10743cbf38143.setDefaultUnit(kony.flex.DP);
            var CopylblIbanNumberKey0h6608ec5a9d241 = new kony.ui.Label({
                "id": "CopylblIbanNumberKey0h6608ec5a9d241",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Product :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblProdName = new kony.ui.Label({
                "id": "lblProdName",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxIbanNumber0a10743cbf38143.add(CopylblIbanNumberKey0h6608ec5a9d241, lblProdName);
            var CopyLabel0g89041ae0f6f46 = new kony.ui.Label({
                "height": "20dp",
                "id": "CopyLabel0g89041ae0f6f46",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEmployerdetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEmployerdetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmployerdetails.setDefaultUnit(kony.flex.DP);
            var lblEmpKey = new kony.ui.Label({
                "id": "lblEmpKey",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Employer :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEmpNAmeVal = new kony.ui.Label({
                "id": "lblEmpNAmeVal",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEmployerdetails.add(lblEmpKey, lblEmpNAmeVal);
            var CopyLabel0gacb7d2090fa46 = new kony.ui.Label({
                "height": "20dp",
                "id": "CopyLabel0gacb7d2090fa46",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAgencyName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAgencyName",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxAgencyName.setDefaultUnit(kony.flex.DP);
            var lblAgencyNameKey = new kony.ui.Label({
                "id": "lblAgencyNameKey",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Agency Name :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAgencyNameVal = new kony.ui.Label({
                "id": "lblAgencyNameVal",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAgencyName.add(lblAgencyNameKey, lblAgencyNameVal);
            var CopyLabel0a7a564f00a9041 = new kony.ui.Label({
                "height": "20dp",
                "id": "CopyLabel0a7a564f00a9041",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSalaryAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSalaryAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxSalaryAmount.setDefaultUnit(kony.flex.DP);
            var lblSalAmountKey = new kony.ui.Label({
                "id": "lblSalAmountKey",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Salary Amount :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSalAmountVal = new kony.ui.Label({
                "id": "lblSalAmountVal",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSalaryAmount.add(lblSalAmountKey, lblSalAmountVal);
            var CopyLabel0j581eeedd7b745 = new kony.ui.Label({
                "height": "20dp",
                "id": "CopyLabel0j581eeedd7b745",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEmpStartDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEmpStartDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmpStartDate.setDefaultUnit(kony.flex.DP);
            var lblEmpStartKey = new kony.ui.Label({
                "id": "lblEmpStartKey",
                "isVisible": true,
                "left": "0",
                "skin": "sknIcnCloseFntSize15px",
                "text": "Employment Start Date :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblStartDateVal = new kony.ui.Label({
                "id": "lblStartDateVal",
                "isVisible": true,
                "left": "10px",
                "skin": "h",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEmpStartDate.add(lblEmpStartKey, lblStartDateVal);
            var CopyLabel0h8e74506707441 = new kony.ui.Label({
                "height": "20dp",
                "id": "CopyLabel0h8e74506707441",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxIBanFile0g3227afc6f1f4b = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "CopyflxIBanFile0g3227afc6f1f4b",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "90%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxIBanFile0g3227afc6f1f4b.setDefaultUnit(kony.flex.DP);
            var lblSanadStatus = new kony.ui.Label({
                "id": "lblSanadStatus",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13latoRegularB2BDCBRed",
                "text": "IBAN File Download",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxIBanFile0g3227afc6f1f4b.add(lblSanadStatus);
            var CopyLabel0f592dcc65e9641 = new kony.ui.Label({
                "height": "20dp",
                "id": "CopyLabel0f592dcc65e9641",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblTransparent",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCusLoanDetails.add(CopylblHeaderCus0g89398c822d645, CopyflxAdSeparator0e180d16f2a1241, CopyflxPhoneCus0a21bdb93970643, CopyLabel0ab860f22212745, CopyflxCusGender0eb283b3ea53449, CopyLabel0ad94a4707e1d41, CopyflxCusDOB0ac36a988bfc84b, CopyLabel0e8b8a19ab28c49, CopyflxIbanNumber0a10743cbf38143, CopyLabel0g89041ae0f6f46, flxEmployerdetails, CopyLabel0gacb7d2090fa46, flxAgencyName, CopyLabel0a7a564f00a9041, flxSalaryAmount, CopyLabel0j581eeedd7b745, flxEmpStartDate, CopyLabel0h8e74506707441, CopyflxIBanFile0g3227afc6f1f4b, CopyLabel0f592dcc65e9641);
            flxCusDetBasic.add(flxBasicdetails, flxCusLoanDetails);
            var flxFeedback = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "180dp",
                "id": "flxFeedback",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "right": "1%",
                "skin": "slFbox",
                "top": "2%",
                "width": "98%",
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedback.setDefaultUnit(kony.flex.DP);
            var lblFeedback = new kony.ui.Label({
                "height": "30px",
                "id": "lblFeedback",
                "isVisible": true,
                "left": "1%",
                "skin": "CopyslLabel0j366732bbf164a",
                "text": "Remarks",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbFeedback = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "bottom": "0dp",
                "focusSkin": "CopydefTextAreaFocus0f63315ed50f343",
                "id": "tbFeedback",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "numberOfVisibleLines": 3,
                "placeholder": "Write feedback...",
                "skin": "CopyslTextArea0e3888f5724f94b",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "30px",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            flxFeedback.add(lblFeedback, tbFeedback);
            var flxCusDetPopUP = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "10%",
                "id": "flxCusDetPopUP",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBackgroundFFFFFF",
                "width": "100%",
                "zIndex": 10,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxCusDetPopUP.setDefaultUnit(kony.flex.DP);
            var btnCusCancel = new kony.ui.Button({
                "centerY": "50%",
                "height": "40px",
                "id": "btnCusCancel",
                "isVisible": true,
                "right": "250px",
                "skin": "sknbtnf7f7faLatoReg13px485c75Rad20px",
                "text": "REJECT",
                "top": "0%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [3, 0, 3, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknbtnffffffLatoRegular4f555dBorder1px485c75"
            });
            var btnCusApr = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtn003E75LatoRegular13pxFFFFFFRad20px",
                "height": "40px",
                "id": "btnCusApr",
                "isVisible": true,
                "minWidth": "100px",
                "right": "20px",
                "skin": "sknBtn003E75LatoRegular13pxFFFFFFRad20px",
                "text": "APPROVE",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [3, 0, 3, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtn005198LatoRegular13pxFFFFFFRad20px"
            });
            flxCusDetPopUP.add(btnCusCancel, btnCusApr);
            flxHeader.add(flxTopBar, flxClose, flxChannelInfo, flxAdSeparator, flxCusDetBasic, flxFeedback, flxCusDetPopUP);
            flxCustomerDetails.add(flxHeader);
            var flxToastMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0%",
                "clipBounds": true,
                "height": "8%",
                "id": "flxToastMessage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "305dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "zIndex": 100,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxToastMessage.setDefaultUnit(kony.flex.DP);
            var toastMessage = new com.adminConsole.common.toastMessage({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "70px",
                "id": "toastMessage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "adminConsole",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxToastMessage.add(toastMessage);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "right": "0px",
                "skin": "sknLoadingBlur",
                "top": "0dp",
                "zIndex": 10,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "75px",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "75px",
                "zIndex": 1,
                "appName": "adminConsole"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "50px",
                "id": "imgLoading",
                "isVisible": true,
                "skin": "slImage",
                "src": "loadingscreenimage.gif",
                "width": "50px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoading.add(flxImageContainer);
            this.add(flxMain, flxCustomerDetails, flxToastMessage, flxLoading);
        };
        return [{
            "addWidgets": addWidgetsfrmCSAPortal,
            "enabledForIdleTimeout": true,
            "id": "frmCSAPortal",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_i6ee64dccb2b4abe965f9395f54e0ea9(eventobject);
            },
            "skin": "slForm",
            "appName": "adminConsole"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});